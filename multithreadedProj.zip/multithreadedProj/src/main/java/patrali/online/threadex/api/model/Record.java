package patrali.online.threadex.api.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Record {

    @Override
    public String toString() {
        return "blackListedIps=" + blackListedIps ;
    }

    public List<String> getBlackListedIps() {
        return blackListedIps;
    }

    public void setBlackListedIps(List<String> blackListedIps) {
        this.blackListedIps = blackListedIps;
    }

    private List<String> blackListedIps = new ArrayList<>();

    public Record()
    {

    }


}
