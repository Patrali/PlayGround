package patrali.online.threadex.api.batchOperations;

import patrali.online.threadex.api.ApplicationConfig;
import patrali.online.threadex.api.model.Record;
import patrali.online.threadex.api.utils.ApplicationEnvironment;

import java.io.File;
import java.lang.invoke.MethodHandles;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import patrali.online.threadex.api.utils.Constants;
import patrali.online.threadex.api.utils.RecordQueue;


@Component
@Scope("prototype")
public class Processor
{
	private static final Logger LOG = LoggerFactory.getLogger( MethodHandles.lookup().lookupClass() );

    private RecordQueue<Map<String,Record>> transformerQueue = null;
    private RecordQueue<Map<String,Record>> writerQueue = null;
    
    private Reader readerTask;
    private Runnable[] transformerThreads;
    private Writer writerTask;


    private Exception errorException = null;
   private File inputFile = null;

    private boolean threadsStarted = false;

    private int noOfSuccess;
    private long uploadId = 0;
    
    private Map<String, String> outputParameters;
    AtomicInteger batch = new AtomicInteger(0);

    private ThreadPoolTaskExecutor taskExecutor = null;



    private AtomicInteger recordsToBeUploaded = new AtomicInteger(0);


    @Autowired
    private ApplicationEnvironment ApplicationEnvironment;
    


     private Properties properties = null;
    long endTime = 0;

    public void initialize()
    {
        errorException = null;
        inputFile = null;
        noOfSuccess = 0;
        outputParameters = new HashMap<String, String>();
        batch = new AtomicInteger(0);

    }

    public Map<String, String> runJob()
    {
        int count;
        long cliendId = 0;
        initialize();

        long start = System.nanoTime();

        try
        {
            properties = ApplicationEnvironment.getProperties();
            ApplicationEnvironment.setInputFileFullPath(properties.getProperty(Constants.INPUT_FILE_PATH));
            createAndStartThreads();
        }
        catch (Exception e)
        {
            LOG.error( "Error in processing file "+ ApplicationEnvironment.getInputFileName() +"......" );
            errorException = e;
        }
        LOG.info( "Loading input file "+ ApplicationEnvironment.getInputFileName() +"......" );

         //check active thread, if zero then shut down the thread pool
    	while (errorException == null) 
    	{
            count = taskExecutor.getActiveCount();
    		LOG.trace("Active Threads : {}", count);
    		try 
    		{
    			Thread.sleep(5000);
    		} 
    		catch (InterruptedException e) 
    		{
    			e.printStackTrace();
    		}
    		if (count == 0)
    		{
    			break;
    		}
    	}



        if ( errorException != null )
        {
            LOG.info( "JOB FAILED. Error : " + errorException.getMessage() );
        }
        else
        {
            LOG.info( "JOB SUCCESS" );
        }



        endTime = ( ( System.nanoTime() - start ) / 1000000 );
        LOG.info( "done" );
        LOG.info( "Process took " + endTime + " milliseconds" );

        taskExecutor.shutdown();

        return outputParameters;
    }

    private void createAndStartThreads() {
        LOG.info( "Starting threads ...... " );
        createAllThreads();
        startAllThreads();
        threadsStarted = true;
    }




    private void createAllThreads()
    {
    	batch = new AtomicInteger(0);
    	LOG.info("Creating threads.......");
    	try
        {
            transformerQueue = new RecordQueue<Map<String,Record>>(ApplicationEnvironment.getqSize());
            writerQueue = new RecordQueue<Map<String,Record>>(ApplicationEnvironment.getqSize());

            readerTask = ApplicationConfig.getContext().getBean(Reader.class, transformerQueue, "Reader-" + 1, this);

            transformerThreads = new Transformer[ApplicationEnvironment.getMaxWorkerThreads()];
            for (int i = 0; i < ApplicationEnvironment.getMaxWorkerThreads(); i++) {
                transformerThreads[i] = ApplicationConfig.getContext().getBean(Transformer.class, transformerQueue, writerQueue, "Transformer-" + i, i, this);
            }


            writerTask = ApplicationConfig.getContext().getBean(Writer.class, writerQueue,"Writer-"+1,1, this);


        }
        catch(Exception e)
        {
            LOG.error(e.getMessage());
            this.errorException = e;
            throw new RuntimeException(e);
        }
        
    }
    

    private void startAllThreads()
    {
    	LOG.info("Strating threads.......");

    	if( taskExecutor == null )
    	{
            taskExecutor = ApplicationConfig.getThreadPoolTaskExcutor();
        }

        try
        {
            taskExecutor.execute( readerTask );

            for ( Runnable task : transformerThreads)
            {
                taskExecutor.execute( task );
            }

            taskExecutor.execute(writerTask);
        }
        catch(Throwable  e)
        {
            LOG.error( e.getMessage() );
            throw new RuntimeException(e);
        }

     }

    public boolean getThreadsStarted()
    {
        return threadsStarted;
    }




	public Exception getErrorException() {
		return errorException;
	}


	public void setErrorException(Exception errorException) {
		this.errorException = errorException;
	}

    public AtomicInteger getRecordsToBeUploaded() {
        return recordsToBeUploaded;
    }

    public void setRecordsToBeUploaded(AtomicInteger recordsToBeUploaded) {
        this.recordsToBeUploaded = recordsToBeUploaded;
    }

}
