package patrali.online.threadex.api.utils;

import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.commons.io.output.CountingOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.lang.invoke.MethodHandles;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class
FileUtilities
{

    private static final Logger LOG = LoggerFactory.getLogger( MethodHandles.lookup().lookupClass() );

    public static void copyFile( File sourceFile, File destFile ) throws Exception
    {
        File destinationFile = destFile.isDirectory() ?
                new File( destFile.getAbsolutePath(), sourceFile.getName() ) :
                destFile;
        InputStream inStream = null;
        OutputStream outStream = null;

        try
        {
            if ( sourceFile.exists() )
            {

                inStream = new FileInputStream( sourceFile );
                outStream = new FileOutputStream( destinationFile );

                byte[] buffer = new byte[ 1024 ];

                int length;
                //copy the file content in bytes 
                while ( ( length = inStream.read( buffer ) ) > 0 )
                {

                    outStream.write( buffer, 0, length );

                }

                inStream.close();
                outStream.close();

            }

        }
        catch ( IOException e )
        {
            throw new Exception( "Unable to copy file " + sourceFile.getPath() + " to " + destFile.getPath(), e );
        }
    }

    public static void createDir( String dirPath ) throws Exception
    {
        LOG.info( "Creating dir : " + dirPath );
        if ( StringUtils.isEmpty( dirPath ) )
        {
            throw new Exception( "Can not create dir with empty dir path " );
        }

        try
        {
            Path dirPathObj = Paths.get( dirPath );
            Files.createDirectories( dirPathObj );
        }
        catch ( IOException e )
        {
            throw new Exception( "Unable to create dir " + dirPath + ". Error : " + e.getMessage(), e );
        }
    }

    public static void moveFile( File sourceFile, File destFile ) throws Exception
    {
        if ( sourceFile.exists() )
        {
            copyFile( sourceFile, destFile );

            sourceFile.delete();
        }

    }

    /**
     * Archives file specified by sourceFile to the directory named by archiveDir, using sourceFile's filename.
     *
     * @param sourceFile
     * @param archiveDir
     * @throws Exception
     */
    public static void archiveFile( File sourceFile, String archiveDir ) throws Exception
    {

        File archiveFile = new File( archiveDir + File.separator + sourceFile.getName() );

        try
        {
            FileUtilities.moveFile( sourceFile, archiveFile );
        }
        catch ( Exception e )
        {
            LOG.error( "An error occurred in archiveFile(): ", e );
            throw new Exception( "Unable to archive file " + archiveFile );
        }
    }

    /**
     * Archives file specified by sourceFile to the fully path specifed by archiveFilePath.
     *
     * @param sourceFile
     * @param archiveFilePath
     * @throws Exception
     */
    public static void archiveFileToPath( File sourceFile, String archiveFilePath ) throws Exception
    {

        File archiveFile = new File( archiveFilePath );

        try
        {
            FileUtilities.moveFile( sourceFile, archiveFile );
        }
        catch ( Exception e )
        {
            LOG.error( "An error occurred in archiveFileToPath(): ", e );
            throw new Exception( "Unable to archive file " + archiveFile );
        }
    }

    public static void compressFile( String sourceFile, String compressedFile ) throws Exception
    {
        BufferedReader reader = FileUtilities.getBufferedReader( new File( sourceFile ) );
        BufferedWriter writer = FileUtilities.getBufferedWriter( new File( compressedFile ) );

        String inline = null;
        while ( ( inline = reader.readLine() ) != null )
        {

            writer.write( inline );
            writer.newLine();

        }

        reader.close();
        writer.close();
    }

    /**
     * Get the record count for a file
     *
     * @param file
     * @return
     * @throws Exception
     */
    public static int getRecordCount( File file ) throws Exception
    {
        BufferedReader reader = getBufferedReader( file );
        int lines = 0;
        try
        {
            while ( reader.readLine() != null )
                lines++;
            reader.close();
        }
        catch ( IOException e )
        {
            throw new Exception( "Unable to get record count", e );
        }
        return lines;
    }

    public static BufferedReader getBufferedReader( File f ) throws Exception
    {
        BufferedReader reader = null;
        try
        {
            if ( f.getName().endsWith( ".gz" ) )
            {
                System.out.println( "Reading .gz file" );
                reader = new BufferedReader( new InputStreamReader( new GZIPInputStream( new FileInputStream( f ) ) ) );
            }
            else if ( f.getName().endsWith( ".bz2" ) )
            {
                System.out.println( "Reading .bz2 file" );
                reader = new BufferedReader( new InputStreamReader( new BZip2CompressorInputStream( new FileInputStream( f ) ),
                        "ISO-8859-15" ) );
            }
            else
            {
                reader = new BufferedReader( new FileReader( f ) );
            }
        }

        catch ( IOException e )
        {
            throw new Exception( "Unable to get buffered reader for file " + f.getPath(), e );
        }
        return reader;
    }

    /**
     * Method to get a buffered writer that we could pass a CountingOutputStream to, to be able to
     * count the number of bytes that pass through, using the CountingOutputStream
     */

    public static BufferedWriter getCountingBufferedWriter( File f, CountingOutputStream cos ) throws Exception
    {
        BufferedWriter writer = null;
        try
        {
            if ( f.getName().endsWith( ".gz" ) )
            {
                GZIPOutputStream gZipStream = new GZIPOutputStream( cos );
                writer = new BufferedWriter( new OutputStreamWriter( gZipStream, "UTF-8" ) );
            }
            else if ( f.getName().endsWith( ".bz2" ) )
            {
                BZip2CompressorOutputStream bZip2Stream = new BZip2CompressorOutputStream( cos );
                writer = new BufferedWriter( new OutputStreamWriter( bZip2Stream, "UTF-8" ) );
            }
            else
            {
                //Create the uncompressed file
                writer = new BufferedWriter( new OutputStreamWriter( cos, "ISO-8859-15" ) );
            }

        }
        catch ( Exception e )
        {
            throw new Exception( "Unable to get the counting buffered writer for file " + f.getPath(), e );
        }
        return writer;
    }

    public static BufferedWriter getBufferedWriter( File f ) throws Exception
    {
        BufferedWriter writer = null;
        try
        {
            if ( f.getName().endsWith( ".gz" ) )
            {
                writer = new BufferedWriter( new OutputStreamWriter( new GZIPOutputStream( new FileOutputStream( f ) ),
                        "ISO-8859-15" ) );
            }
            else if ( f.getName().endsWith( ".bz2" ) )
            {
                writer = new BufferedWriter(
                        new OutputStreamWriter( new BZip2CompressorOutputStream( new FileOutputStream( f ) ) ) );
            }
            else
            {
                writer = new BufferedWriter( new OutputStreamWriter( new FileOutputStream( f ), "ISO-8859-15" ) );
            }

        }
        catch ( Exception e )
        {
            throw new Exception( "Unable to get buffered writer for file " + f.getPath(), e );
        }
        return writer;
    }

    public static void close( BufferedReader reader )
    {
        try
        {
            reader.close();
        }
        catch ( IOException e )
        {
            LOG.error( "An error occurred in close(): ", e );
        }

    }

    public static void close( BufferedWriter output )
    {
        try
        {
            output.close();
        }
        catch ( IOException e )
        {
            LOG.error( "An error occurred in close(): ", e );
        }

    }

    private static final String SSL_EXECUTATBLE = "/usr/bin/openssl";

    public static void encryptFileOpenSSL256( String directory, String fileName, String iv, String kFile ) throws Exception
    {
        Runtime rt = Runtime.getRuntime();

        String[] arguments = new String[ 11 ];
        arguments[ 0 ] = SSL_EXECUTATBLE;
        arguments[ 1 ] = "enc";
        arguments[ 2 ] = "-aes-256-cbc";
        arguments[ 3 ] = "-iv";
        arguments[ 4 ] = iv;
        arguments[ 5 ] = "-in";
        arguments[ 6 ] = fileName;
        arguments[ 7 ] = "-out";
        arguments[ 8 ] = fileName + ".encrypted";
        arguments[ 9 ] = "-kfile";
        arguments[ 10 ] = kFile;

        Process p = rt.exec( arguments, null, new File( directory ) );
        p.waitFor();

        BufferedReader reader = new BufferedReader( new InputStreamReader( p.getErrorStream() ) );
        String line = reader.readLine();

        while ( line != null )
        {
            System.out.println( line );
            line = reader.readLine();
        }
        // Show exit code of process
        if ( p.exitValue() != 0 )
        {
            System.out.println( "exitValue = " + p.exitValue() );
            throw new Exception( "Unable to encrypt file " + fileName + ". Return code " + p.exitValue() );
        }
        else
        {
            System.out.println( "exitValue = " + p.exitValue() );
        }

    }

    public static void checkFileGrowing( File currentFile ) throws InterruptedException
    {
        boolean fileGrowing = true;
        long fileSize = currentFile.length();

        while ( fileGrowing )
        {
            Thread.sleep( 10000 );
            long newSize = currentFile.length();

            if ( fileSize == newSize )
            {
                fileGrowing = false;
            }
            else
            {
                fileSize = newSize;
            }
        }
    }

    /**
     * Method to read the content of a file and return it as a string
     *
     * @param file
     * @return content of the file as a string
     * @throws IOException
     */
    public static String readFile( String file ) throws IOException
    {
        return new String( Files.readAllBytes( Paths.get( file ) ) );
    }

    private static final String specialCharacters = "[^A-Za-z0-9_\\-\\.]";

    static String stripInvalidCharacters( String fileName )
    {
        return fileName.replaceAll( specialCharacters, "" );
    }

    /**
     * @return A list of file objects in <strong>sourceDirectory</strong> matching <strong>fileMask</strong>,
     * an empty list if sourceDirectory is invalid or there are no matching files
     */
    public static List<File> getFilesWithWildcard( String sourceDirectory, String fileMask )
    {
        File dir = new File( sourceDirectory );
        FileFilter fileFilter = new WildcardFileFilter( fileMask, IOCase.INSENSITIVE );
        File[] files = dir.listFiles( fileFilter );

        if ( null == files || files.length <= 0 )
        {
            return Collections.emptyList();
        }

        return Arrays.stream( files ).filter( File::isFile ).collect( Collectors.toList() );
    }

    /**
     * @param fullPathAndFile The full directory path with file mask
     * @return A two element array, the first being directory, the second being the mask
     */
    public static String[] splitPathAndMask( String fullPathAndFile )
    {
        if ( null == fullPathAndFile || fullPathAndFile.trim().isEmpty() )
        {
            return new String[] { "", "" };
        }

        if ( !fullPathAndFile.contains( "/" ) )
        {
            return new String[] { fullPathAndFile, "" };
        }
        return new String[] { fullPathAndFile.substring( 0, fullPathAndFile.lastIndexOf( "/" ) ),
                fullPathAndFile.substring( fullPathAndFile.lastIndexOf( "/" ) + 1, fullPathAndFile.length() )
        };
    }

    public static boolean isDirValid( String dir )
    {
        return Files.isDirectory( Paths.get( dir ) );
    }

    public static boolean isFileValid( String fullFilePath )
    {
        Path path = Paths.get( fullFilePath );

        return path != null && !Files.isDirectory( path ) && Files.isReadable( path ) && Files.isRegularFile( path );
    }

    public static String trimExt( String str )
    {
        if ( null == str )
        {
            return "";
        }
        if ( !str.contains( "." ) )
        {
            return str;
        }
        else
        {
            return trimExt( str.substring( 0, str.lastIndexOf( "." ) ) );
        }

    }

}
