package patrali.online.threadex.api;


import patrali.online.threadex.api.utils.ApplicationEnvironment;
import patrali.online.threadex.api.utils.Constants;
import patrali.online.threadex.api.batchOperations.Processor;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


public class MasterProcessor
{
    Properties properties;

    public MasterProcessor()
    {
        System.out.println("Initiating master service processor for adwords api");
    }

    public MasterProcessor(Properties properties)
    {
        System.out.println("Initiating master service processor for adwords api with properties");
        this.properties = properties;
    }

    public Map<String, String> runJob()
    {
        HashMap<String, String>  outputParameters = new HashMap<String, String>();
        int count;

        Processor processor
                = ApplicationConfig.getContext().getBean( Processor.class );
        ApplicationEnvironment appEnv = ApplicationConfig.getContext().getBean( ApplicationEnvironment.class );
        appEnv.setProperties(properties);

        processor.runJob();

        return outputParameters;

    }


    public static void main( String args[] )
    {
        Properties properties = new Properties();

        properties.setProperty(Constants.INPUT_FILE_PATH,"/online/data.txt");
        MasterProcessor master = new MasterProcessor(properties);
        master.runJob();


    }
}
