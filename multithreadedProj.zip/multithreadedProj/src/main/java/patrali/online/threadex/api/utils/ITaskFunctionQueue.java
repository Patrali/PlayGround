package patrali.online.threadex.api.utils;

import java.util.concurrent.TimeUnit;

public interface ITaskFunctionQueue< E >
{

    public void put(final E element) throws InterruptedException;

    public E poll(final long timeout, final TimeUnit unit) throws InterruptedException;

    boolean isOpen();

    boolean isNotEmpty();

    public void close();

}
