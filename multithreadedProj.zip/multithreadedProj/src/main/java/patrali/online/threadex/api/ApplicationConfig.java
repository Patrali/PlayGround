package patrali.online.threadex.api;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;


public class ApplicationConfig
{
	private static ApplicationContext context;
	
	private static ThreadPoolTaskExecutor taskExecutor;
	
	public static void setContext(ApplicationContext acontext)
	{
		context = acontext;
	}


	
	public static ApplicationContext getContext()
	{
		if( context == null )
		{
			context = new ClassPathXmlApplicationContext("threadContext.xml");
		}
		
		return context;
	}
	
	public static ThreadPoolTaskExecutor getThreadPoolTaskExcutor()
	{

		taskExecutor = (ThreadPoolTaskExecutor) context.getBean("taskExecutor");
		return taskExecutor;
	}


}
