package patrali.online.threadex.api.utils;

import java.util.HashMap;
import java.util.Map;

public class Constants {

	public static final String DELIMITER = "DELIMITER";
	public static final String INPUT_FILE_PATH="input_file_path";


	public static final String INPUT_REJECT_FILE_PATH = "input_reject_file_path";
	public static final String REJECT_FILE_EXT = ".rej";

}