package patrali.online.threadex.api.utils;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;


public class RecordQueue< E >
    implements ITaskFunctionQueue<E>
{

    /**
     * The queue to be managed.
     */
    private final BlockingQueue<E> queue;
    private int capacity = 10000;         // the size of the queue will affect the old generation memory of the heap
    private volatile boolean closed;
    private String name = "RecordQueue";

    /**
     * Constructor for LogQueue
     */
    public RecordQueue()
    {
        super();

        queue = new LinkedBlockingQueue<E>( capacity );
    }

    public RecordQueue(String name )
    {
        this();

        this.name = name;
    }

    /**
     * Constructor for LogQueue
     * 
     * @param capacity The capacity of the queue
     */
    public RecordQueue(final int capacity )
    {
        super();

        this.capacity = capacity;

        queue = new LinkedBlockingQueue<E>( capacity );
    }
    public RecordQueue(final int capacity, String name )
    {
        super();
        this.name = name;
        this.capacity = capacity;
        queue = new LinkedBlockingQueue<E>( capacity );
    }

    /**
     * Marks the queue as closed.
     */
    public void close()
    {
        setClosed( true );
    }

    /**
     * @return the capacity
     */
    public int getCapacity()
    {
        return capacity;
    }

    /**
     * @return the name
     */
    public synchronized String getName()
    {
        return name;
    }

    /**
     * @return the closed
     */
    public synchronized boolean isClosed()
    {
        return closed;
    }

    /**
     * Returns whether there are any elements in the queue.
     * 
     * @return True, if there are no elements in the queue
     */
    public boolean isEmpty()
    {
        return queue.isEmpty();
    }

    public boolean isNotEmpty()
    {
        return !queue.isEmpty();
    }

    public boolean isOpen()
    {
        return !isClosed();
    }

    /**
     * Removes the head of the queue, blocking if an element is not available.
     * 
     * @return The element at the head of the queue
     * @throws InterruptedException
     * @see BlockingQueue
     */
    public E poll() throws InterruptedException
    {
        return queue.take();
    }

    /**
     * Removes the head of the queue, blocking if an element is not available.
     * 
     * @param timeout The timeout value
     * @param unit The timeout unit
     * @return The element at the head of the queue
     * @throws InterruptedException
     * @see BlockingQueue
     */
    public E poll( final long timeout, final TimeUnit unit ) throws InterruptedException
    {
        return queue.poll( timeout, unit );
    }

    public void put( final E element ) throws InterruptedException
    {
        boolean successFlag = false;
        while ( !successFlag )
        {
            if ( isClosed() )
            {
                throw new IllegalStateException( getName() + " is closed.  Cannot add elements to a closed queue!" );
            }
                queue.put( element );
                successFlag = true;
        }
    }

    /**
     * @param closed the closed to set
     */
    private synchronized void setClosed( final boolean closed )
    {
        this.closed = closed;
    }

    /**
     * @param name the name to set
     */
    public synchronized void setName( final String name )
    {
        this.name = name;
    }

    /**
     * Returns the number of elements in the queue.
     * 
     * @return The queue size
     */
    public int size()
    {
        return queue.size();
    }

}
