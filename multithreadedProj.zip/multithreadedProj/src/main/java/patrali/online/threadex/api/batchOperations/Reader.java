package patrali.online.threadex.api.batchOperations;


import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.util.*;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import patrali.online.threadex.api.model.Record;
import patrali.online.threadex.api.utils.ApplicationEnvironment;
import patrali.online.threadex.api.utils.FileUtilities;
import patrali.online.threadex.api.utils.RecordQueue;


import java.text.SimpleDateFormat;


@Component
@Scope("prototype")
public class Reader implements Runnable
{
	private static final Logger LOG = LoggerFactory.getLogger( MethodHandles.lookup().lookupClass() );
   private RecordQueue<Map<String,Record>> destQueue = null;
    private Date startTime;
    private Date finishTime;
    private File inputFile;
    private boolean isTimeToWait = false;
    private String name;
    private Record record;
    
    @Autowired
    ApplicationEnvironment applicationEnvironment;

    private Processor parent;

    @Value( "#{app_props[T( patrali.online.threadex.api.utils.Constants).DELIMITER]?:','}" )
    private String delimiter;


    private static final String UPLOAD_ZONE = "America/Denver";


    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd hhmmss Z", Locale.US);

    public Reader(RecordQueue<Map<String,Record>> uploaderQueue, String name, Processor parent)
    {
        this.destQueue = uploaderQueue;
        this.parent = parent;
        this.setName(name);
    }
    

    public void run()
    {
        LOG.info( "Reader started" );
        startTime = new Date();

        sdf.setTimeZone(TimeZone.getTimeZone(UPLOAD_ZONE));
        LOG.info("Start time : " + sdf.format(startTime));


        this.inputFile = new File( "/online/data.txt" );
 		LOG.info("Reading records : " );
 		String[] recordFields = null;

        Map<String,Record> allRecords = new HashMap<>();
		try (BufferedReader reader = FileUtilities.getBufferedReader(inputFile))
        {

			String inline = null;
            Record rec=null;
			while ( ( inline = reader.readLine() ) != null )
			{

                    if(StringUtils.isEmpty(inline))
                    {
                        continue;
                    }
                    recordFields = inline.split(delimiter,-1);

                if( allRecords.containsKey(recordFields[0]) )
                {
                    allRecords.get(recordFields[0]).getBlackListedIps().add(recordFields[1]);
                }
                else
                {
                    rec=new Record();
                    rec.getBlackListedIps().add(recordFields[1]);
                    allRecords.put(recordFields[0],rec);
                }
                    //.record = new Record(recordFields);

					parent.getRecordsToBeUploaded().addAndGet(1);



					if (parent.getRecordsToBeUploaded().intValue() % (50000) == 0)
					{
						LOG.info(parent.getRecordsToBeUploaded().intValue() + " Records have been read");
					}

                   // OAP_DW_OWNER.TABLE_UTIL.ADD_GRANTS( v_owner || '.' || get_alter_table_data_rec.physical_table_name );;


			}
            destQueue.put(allRecords);

		}
		catch (  Exception  e )
		{
			handleException(e);
		}


		finishTime = new Date();
		LOG.info("Total Records Read: " + parent.getRecordsToBeUploaded().intValue());
		destQueue.close();

    }


    private void handleException( Exception eArg )
    {
        LOG.error(eArg.getMessage());
        while ( !parent.getThreadsStarted() )
        {
            try
            {
                Thread.sleep( 1000 );
            }
            catch ( InterruptedException e )
            {
                LOG.error(e.getMessage());
            }
        }
        
        parent.setErrorException(eArg );

    }

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}



}
