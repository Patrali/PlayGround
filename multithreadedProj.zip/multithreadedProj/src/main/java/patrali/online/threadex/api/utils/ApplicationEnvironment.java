package patrali.online.threadex.api.utils;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("singleton")
public class ApplicationEnvironment
{

    private Logger LOG = Logger.getLogger( ApplicationEnvironment.class );

    private Properties properties;


	@Value( "#{app_props[\"DEFAULT_RESPONSE_FILE_PATH\"]?:''}" )
    private String defaultResponseFilePath;

	@Value( "#{app_props[\"RESPONSE_FILE_PREFIX\"]?:''}" )
	private String responseFilePref;

	@Value( "#{app_props[\"INPUT_FILE_PATH\"]?:''}" )
	private String fileDir = "";


	@Value( "#{app_props[\"QSIZE\"]?:'10000'}" )
    private int qSize;

	@Value( "#{app_props[\"MAX_READER_THREADS\"]?:'1'}" )
    private int maxReaderThreads;

	@Value( "#{app_props[\"MAX_WORKER_THREADS\"]?:'1'}" )
    private int maxWorkerThreads;



	private String inputFileName = "";
	private String inputFileFullPath = "";
	private String timeStarted = "";
	private String timeEnded = "";
	//SimpleDateFormat sdf = new SimpleDateFormat("", Locale.US);

    public ApplicationEnvironment()
	{

	}

	public String getDefaultResponseFilePath() {
		return defaultResponseFilePath;
	}

	public void setDefaultResponseFilePath(String defaultResponseFilePath) {
		this.defaultResponseFilePath = defaultResponseFilePath;
	}

	public int getqSize() {
		return qSize;
	}

	public void setqSize(int qSize) {
		this.qSize = qSize;
	}

	public int getMaxReaderThreads() {
		return maxReaderThreads;
	}

	public void setMaxReaderThreads(int maxReaderThreads) {
		this.maxReaderThreads = maxReaderThreads;
	}

	public int getMaxWorkerThreads() {
		return maxWorkerThreads;
	}

	public void setMaxWorkerThreads(int maxWorkerThreads) {
		this.maxWorkerThreads = maxWorkerThreads;
	}
	public String getFileDir() {
		return fileDir;
	}

	public void setFileDir(String fileDir) {
		this.fileDir = fileDir;
	}

	public String getInputFileName() {
		return inputFileName;
	}

	public void setInputFileName(String inputFileName) {
		this.inputFileName = inputFileName;
	}

	public String getInputFileFullPath() {
		return inputFileFullPath;
	}

	public void setInputFileFullPath(String inputFileFullPath)
	{
		this.inputFileFullPath = inputFileFullPath;

		if ( !StringUtils.isEmpty( this.inputFileFullPath ) )
		{
			Path path = Paths.get( this.inputFileFullPath );
			setFileDir( path.getParent().toString() + File.separator );
			setInputFileName( path.getFileName().toString() );
		}
	}

	public String getTimeStarted() {
		return timeStarted;
	}

	public void setTimeStarted(String timeStarted) {
		this.timeStarted = timeStarted;
	}

	public String getTimeEnded() {
		return timeEnded;
	}

	public void setTimeEnded(String timeEnded) {
		this.timeEnded = timeEnded;
	}

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public String getResponseFilePref()
	{
		return responseFilePref;
	}

	public void setResponseFilePref( String responseFilePref )
	{
		this.responseFilePref = responseFilePref;
	}



}
