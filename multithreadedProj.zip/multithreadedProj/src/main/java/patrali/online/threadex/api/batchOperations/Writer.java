package patrali.online.threadex.api.batchOperations;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import patrali.online.threadex.api.model.Record;
import patrali.online.threadex.api.utils.ApplicationEnvironment;
import patrali.online.threadex.api.utils.RecordQueue;

import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;


@Component
@Scope("prototype")
public class Writer implements  Runnable
{
    private static final Logger LOG = LoggerFactory.getLogger( MethodHandles.lookup().lookupClass() );
    private RecordQueue<Map<String,Record>> writerQueue;

    @Value( "#{app_props[T( patrali.online.threadex.api.utils.Constants).DELIMITER]?:','}" )
    private String delimiter;


    private boolean stop = false;
    private Processor parent;

    @Autowired
    ApplicationEnvironment appEnv;

    private String name;
    private int id = 0 ;
    Properties properties = null;

    public Writer(RecordQueue<Map<String,Record>> uploadQueue, String name, int id, Processor parent)
    {
        this.writerQueue = uploadQueue;
        //this.parent = parent;
        this.setName(name);
        this.id = id;
        LOG.info("ResponseHandler " + name + " is initialized. Id : " + id);
        
    }

    public void run()
    {
        LOG.info( "Writer"+this.getName()+" started" );
        long recordCount = 0;
        properties = appEnv.getProperties();


        try
        {
            Map<String,Record> records = null;
            while ( ( ( writerQueue.isOpen() || writerQueue.isNotEmpty() )  ) )
	        {

	            try
	            {
	                records = writerQueue.poll( 10, TimeUnit.SECONDS );
	            }
	            catch ( InterruptedException e )
	            {
	                continue;
	            }
	            if ( records == null )
	                continue;

                for (Map.Entry<String, Record> entry : records.entrySet()) {
                    LOG.info("IP address : " + entry.getKey()
                            + " black listed : "
                            + entry.getValue().toString());
                }
                LOG.info(records.toString());
	        }

        }
        catch ( Exception e )
        {
            LOG.error(e.getMessage());
            parent.setErrorException(e);
            throw new RuntimeException(e);
        }
    }


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


}
