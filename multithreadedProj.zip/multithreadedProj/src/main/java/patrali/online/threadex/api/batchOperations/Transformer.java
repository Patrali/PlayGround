package patrali.online.threadex.api.batchOperations;

import java.util.*;


import java.net.SocketException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import patrali.online.threadex.api.model.Record;
import patrali.online.threadex.api.utils.ApplicationEnvironment;
import patrali.online.threadex.api.utils.RecordQueue;

import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.util.concurrent.atomic.AtomicInteger;

@Component
@Scope("prototype")
public class Transformer implements  Runnable
{
    private static final Logger LOG = LoggerFactory.getLogger( MethodHandles.lookup().lookupClass() );
    private RecordQueue<Map<String,Record>> transformerQueue;
    private RecordQueue<Map<String,Record>> destQueue;

    private Processor parent;

    @Autowired
    private ApplicationEnvironment appEnv;

    private String name;

    Properties properties = null;



    public Transformer()
    {}

    public Transformer(RecordQueue<Map<String,Record>> transformerQueue,
                       RecordQueue<Map<String,Record>> destinationQueue,
                       String name, int id, Processor parent)
    {
        this.transformerQueue = transformerQueue;
        this.destQueue = destinationQueue;
        //this.parent = parent;
        this.setName(name);
        LOG.info("Transformer " + name + " is initialized. Id : " + id);
        
    }


    public void run()
    {
        LOG.info( "Transformer "+this.getName()+" started" );
        long recordCount = 0;
        properties = appEnv.getProperties();

        try {

            while (transformerQueue.isOpen() || transformerQueue.isNotEmpty()) {
                Map<String,Record> record = null;
                try {
                    record = transformerQueue.poll(10, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    continue;
                }
                if (record == null)
                    continue;

                recordCount++;
                destQueue.put(record);

            }
        }
        catch ( Exception  e )
        {
            LOG.error(e.getMessage());
            parent.setErrorException(e);
            throw new RuntimeException(e);
        }
        finally
        {
            destQueue.close();
        }
    }

    public void logAndThrow(Exception e,String msg)
    {
        LOG.error( msg );
        throw new RuntimeException(msg,e);
    }




	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


}


