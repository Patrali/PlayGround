#!/usr/bin/env /usr/local/groovy/bin/groovy

def cli = new CliBuilder(usage: 'build.groovy [-e environment][-h]')
cli.e(args: 1, longOpt: 'environment', required: true, argName: 'environment', 'The environment to build for: dev, test, prod')
cli.h(longOpt: 'help','help information')

def opt = cli.parse(args)

if(!opt) {
    System.exit 1
}
if (opt.h) {
    cli.usage()
    System.exit 0
}
println "RUNNING BUILDER FOR: ${opt.e}"
profile = opt.e


MVN_HOME="/usr/local/maven"
MVN="${MVN_HOME}/bin/mvn"
if(System.getProperty('os.name')== 'Windows XP')
{
    MVN_HOME=System.getenv('M2_HOME')
    MVN="cmd /c ${MVN_HOME}\\bin\\mvn"
}

File mvnFile = new File(MVN_HOME)

println "mvnFile: ${mvnFile}"
if(!mvnFile.exists())
{
    println "MAVEN is not located in: ${MVN_HOME}"
    println "Exiting..."
    System.exit 1
}

rootDir = new File("..")
println "root dir: ${rootDir.absolutePath}"

executeProcess("BUILD","${MVN} -P ${profile} deploy")  


void executeProcess(def processName, def processCmd)
{
    def lineBreak = "********************************************************"
    println lineBreak
    println "${processName} - START"
    println lineBreak
    Process process = processCmd.execute(null,rootDir)
    process.in.eachLine { line -> println line }
    process.err.eachLine { line -> println line }
    process.waitFor()
    if(process.exitValue()!=0)
    {
       println "ENCOUNTERED ERROR WHILE RUNNING ${processName}"
       println "EXITING..."
       System.exit 1
    }
    println lineBreak
    println "${processName} - END"
    println lineBreak
}

