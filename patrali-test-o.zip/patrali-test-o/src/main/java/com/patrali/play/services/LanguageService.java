package com.patrali.play.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.lang.invoke.MethodHandles;
import java.util.regex.Pattern;

@Component
public class LanguageService
{
    /*
    Rules to generate:
    Rule 1: If a word begins with a vowel sound, add an "ay" sound to the end of the word. Please note that "xr" and "yt" at the beginning of a word make vowel sounds (e.g. "xray" -> "xrayay", "yttria" -> "yttriaay").
    Rule 2: If a word begins with a consonant sound, move it to the end of the word and then add an "ay" sound to the end of the word. Consonant sounds can be made up of multiple consonants, a.k.a. a consonant cluster (e.g. "chair" -> "airchay").
    Rule 3: If a word starts with a consonant sound followed by "qu", move it to the end of the word, and then add an "ay" sound to the end of the word (e.g. "square" -> "aresquay").
    Rule 4: If a word contains a "y" after a consonant cluster or as the second letter in a two letter word it makes a vowel sound (e.g. "rhythm" -> "ythmrhay", "my" -> "ymay").
     */

    private static final String REGEX_RULE_1 = "^([aeiou]|x[^aeiouy]|y[aeiout])";
    private static final String REGEX_RULE_2_3_4 = "^([b-df-hj-np-tv-xz]?(qu|y)|[b-df-hj-np-tv-xz]+ *?)";
    private static final String REGEX_Y_AT_END = "^([b-df-hj-np-tv-xz]+)";

    private static final Logger LOG = LoggerFactory.getLogger( MethodHandles.lookup().lookupClass() );


    public String translate(String inText)
    {
        Pattern rule1 = Pattern.compile(REGEX_RULE_1,Pattern.CASE_INSENSITIVE);
        Pattern rule2 = Pattern.compile(REGEX_RULE_2_3_4,Pattern.CASE_INSENSITIVE);

        StringBuilder result = new StringBuilder("");

        for (String word: inText.split(" ",-1))
        {
            if (rule1.matcher(word).find())
            {
                result.append(word).append("ay").append(" ");
            }
            else if (rule2.matcher(word).find())
            {

                String[] words= rule2.split(word);

                if(words.length==0)
                {
                    Pattern ruleYAtEnd = Pattern.compile(REGEX_Y_AT_END,Pattern.CASE_INSENSITIVE);
                    words= ruleYAtEnd.split(word);

                }

                result.append(words[1])
                        .append(word.split(words[1])[0])
                        .append("ay")
                        .append(" ");
            }
            else
            {
                result.append(word).append(" ");
            }


        }

        return result.toString().trim();
    }

    public void printTranslated(String provided)
    {
        LOG.info(String.format("===================== Transalated Report ======================"));
        LOG.info(String.format("Provided (English):  %s ",provided));

        LOG.info(String.format("Translated (Pig-Latin):  %s ",translate(provided)));
        LOG.info(System.lineSeparator());
    }

}
