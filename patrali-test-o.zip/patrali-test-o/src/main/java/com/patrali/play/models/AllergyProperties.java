package com.patrali.play.models;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;


@ConfigurationProperties(prefix="myapp.allergies")
@Validated
public class AllergyProperties {

  private int egg;
  private int peanuts;
  private int shellfish;
  private int strawberries;
  private int tomatoes;
  private int chocolate;
  private int pollen;
  private int cats;

    public int getEgg() {
        return egg;
    }

    public void setEgg(int egg) {
        this.egg = egg;
    }

    public int getPeanuts() {
        return peanuts;
    }

    public void setPeanuts(int peanuts) {
        this.peanuts = peanuts;
    }

    public int getShellfish() {
        return shellfish;
    }

    public void setShellfish(int shellfish) {
        this.shellfish = shellfish;
    }

    public int getStrawberries() {
        return strawberries;
    }

    public void setStrawberries(int strawberries) {
        this.strawberries = strawberries;
    }

    public int getTomatoes() {
        return tomatoes;
    }

    public void setTomatoes(int tomatoes) {
        this.tomatoes = tomatoes;
    }

    public int getChocolate() {
        return chocolate;
    }

    public void setChocolate(int chocolate) {
        this.chocolate = chocolate;
    }

    public int getPollen() {
        return pollen;
    }

    public void setPollen(int pollen) {
        this.pollen = pollen;
    }

    public int getCats() {
        return cats;
    }

    public void setCats(int cats) {
        this.cats = cats;
    }




   public Map<String,Integer> getallergenToScoreMap( )
   {

    Field[] fields = this.getClass().getDeclaredFields();
    Map<String,Integer> allergenMapToScore = new HashMap<>();

    Arrays.stream(fields).forEach(field ->
    {
        try
        {
            allergenMapToScore.put(field.getName(),field.getInt(this));
        }
        catch (IllegalAccessException e)
        {
            throw new RuntimeException(e);
        }
    });

    return allergenMapToScore;

  }

    public Map<Integer,String> getScoreToAllergenMap( )
    {
    /*List<Method> methods = Arrays.stream(this.getClass().getDeclaredMethods())
            .filter(m -> m.getName().startsWith("get"))
            .collect(Collectors.toList());*/

        Field[] fields = this.getClass().getDeclaredFields();
        Map<Integer,String> scoreMapToAllergen = new HashMap<>();

        Arrays.stream(fields).forEach(field ->
        {
            try
            {
                scoreMapToAllergen.put(field.getInt(this), field.getName());
            }
            catch (IllegalAccessException e)
            {
                throw new RuntimeException(e);
            }
        });

        return scoreMapToAllergen;

    }


}
