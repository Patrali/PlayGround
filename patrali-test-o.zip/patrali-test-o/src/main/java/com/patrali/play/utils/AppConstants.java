package com.patrali.play.utils;

public class AppConstants
{
    public static final String TYPE_KEY_SCORE = "type_key_score";
    public static final String TYPE_KEY_NAME_ALLERGEN = "type_key_name_allergen";
}
