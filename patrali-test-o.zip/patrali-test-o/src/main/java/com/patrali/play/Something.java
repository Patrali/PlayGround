package com.patrali.play;

import org.springframework.stereotype.Component;

@Component
public class Something
{
    public void printHello()
    {
        System.out.println("Say Hello");
    }
}
