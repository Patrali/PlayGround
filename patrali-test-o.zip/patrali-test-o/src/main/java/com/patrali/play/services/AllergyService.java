package com.patrali.play.services;

import com.patrali.play.models.AllergyProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.invoke.MethodHandles;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


@Component
public class AllergyService {
  
  @Autowired
  private AllergyProperties allergyProperties;

  private static final Logger LOG = LoggerFactory.getLogger( MethodHandles.lookup().lookupClass() );

  private int[] sortedAllergenScores;
  private List<Integer> recognisedAlergen = new ArrayList<>();


  private Map<String,Integer> allergenMapToScore;
  private Map<Integer,String> scoreMapToAllergen;


  public void setSortedAllergenTestEnv()
  {
    allergenMapToScore = allergyProperties.getallergenToScoreMap();
    scoreMapToAllergen = allergyProperties.getScoreToAllergenMap();
    sortedAllergenScores = new int[scoreMapToAllergen.size()];
    int i = 0;

    //sloppy way. However, I don't have time left
    Object[] tmp = scoreMapToAllergen.keySet().toArray();
    for(Object score : tmp)
    {
      sortedAllergenScores[i++] = (Integer)score;
    }

    Arrays.sort(sortedAllergenScores);
  }

  public int findstartIndex(int target)
  {
    int totalAllowedScore = IntStream.of(sortedAllergenScores).sum();
    if ( target > totalAllowedScore)
    {
      return 0;
    }
    if (sortedAllergenScores[0] > target)
    {
      return -1;
    }
    if( sortedAllergenScores == null || sortedAllergenScores.length == 0 )
    {
      return -1;
    }
    else
    {
      return findPosition( target, 0, sortedAllergenScores.length-1);

    }
  }

  public int findPosition( int target, int start, int end)
  {
    while ( start+1<end)
    {
      if (sortedAllergenScores[end] <= target)
      {
        return end;
      }

      int mid = start + (end-start)/2;

      if(sortedAllergenScores[mid] == target)
      {
        return mid;
      }
      else if(sortedAllergenScores[mid] < target)
      {
        if( mid+1 == end )
        {
          return mid;
        }
        start = mid;

      }
      else if(sortedAllergenScores[mid] > target)
      {
        if( start+1 == mid )
        {
          return start;
        }
        end = mid;
      }

    }
    return -1;

  }


  public List<Integer> findAllergies(int allergyScore)
  {
    recognisedAlergen.clear();
    int searchIndex = findstartIndex(allergyScore);

    if (searchIndex<0)
    {
      return recognisedAlergen;
    }

    if (searchIndex==0)
    {
      recognisedAlergen.add(sortedAllergenScores[searchIndex]);
      return recognisedAlergen;
    }

    int remainingScore = Integer.MAX_VALUE;

    while(  remainingScore!=0)
    {
      recognisedAlergen.add(sortedAllergenScores[searchIndex]);
      remainingScore = allergyScore % sortedAllergenScores[searchIndex];
      searchIndex = findstartIndex(remainingScore);
    }

    return recognisedAlergen;
  }

  public boolean isAllergicTo(String allergen, int score)
  {
    if( scoreMapToAllergen.containsKey(score) )
    {
      return scoreMapToAllergen.get(score).equalsIgnoreCase(allergen);

    }
    List<Integer> confirmedList = findAllergies(score).stream()
            .filter(e->
                    {
                      return (scoreMapToAllergen.containsKey(e)  && scoreMapToAllergen.get(e).equalsIgnoreCase(allergen)) ? true : false;
                    }
            )
            .collect (Collectors.toList());

    if(confirmedList.size()==0)
    {
      return false;
    }

    if (confirmedList.size() == 1 )
    {
      return true;

    }

    throw new RuntimeException("Something went wrong in allergy test");

  }

  public void setSortedAllergenScoresForTest( int[] allergenScores)
  {
    sortedAllergenScores = allergenScores;
    Arrays.sort(sortedAllergenScores);
  }


  public void setAllergenMapToScore(Map<String, Integer> allergenMapToScore)
  {
    this.allergenMapToScore = allergenMapToScore;
  }

  public void setScoreMapToAllergen(Map<Integer, String> scoreMapToAllergen)
  {
    this.scoreMapToAllergen = scoreMapToAllergen;
  }

  public void printAllergyTestReport(int score)
  {
    LOG.info(String.format("===================== Allergy Report ======================"));
    LOG.info(String.format("The allergy report for the score %s :",Integer.toString(score)));

    findAllergies(score).forEach(e->LOG.info(
            String.format("Allergy confirmed : %s " , scoreMapToAllergen.get(e).toUpperCase())
    ));
    LOG.info(System.lineSeparator());
   }



}
