package com.patrali.play;

import com.patrali.play.models.AllergyProperties;
import com.patrali.play.services.AllergyService;
import com.patrali.play.services.LanguageService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;


@SpringBootApplication
@EnableConfigurationProperties(AllergyProperties.class)
public class SpringBootApp {

  public static void main(String[] args)
  {
    ApplicationContext context = SpringApplication.run(SpringBootApp.class, args);

    AllergyService allergyService = context.getBean(AllergyService.class);
    allergyService.setSortedAllergenTestEnv();

    allergyService.printAllergyTestReport(5);
    allergyService.printAllergyTestReport(14);
    allergyService.printAllergyTestReport(13);
    allergyService.printAllergyTestReport(257);

    LanguageService languageService = context.getBean(LanguageService.class);
    languageService.printTranslated("I will do it");


  }
  
}
