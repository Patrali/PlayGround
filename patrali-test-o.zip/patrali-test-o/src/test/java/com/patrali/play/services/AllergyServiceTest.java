package com.patrali.play.services;


import com.patrali.play.services.AllergyService;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ImportResource;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.Assert;
import org.testng.annotations.Test;


import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;


/*@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/testContext.xml"})*/
/*@TestPropertySource(
        locations = "classpath:application.yml")*/
/*@RunWith(SpringRunner.class)
@SpringBootTest
@ImportResource("/testContext.xml")*/
public class AllergyServiceTest
{

    /*@Autowired
    private ApplicationContext context;*/

    private AllergyService service;

    private static final String EGG = "egg";
    private static final String PEANUTS = "peanuts";
    private static final String SHELLFISH = "shellfish";
    private static final String STRAWBERRIES = "strawberries";
    private static final String TOMATOS = "tomatoes";
    private static final String CHOCOLATE = "chocolate";
    private static final String POLLEN = "pollen";
    private static final String CATS = "cats";

    private static final int NO_ALLERGY_SCORE = 0;
    private static final int EGG_ALLERGY_SCORE = 1;
    private static final int PEANUTS_ALLERGY_SCORE = 2;
    private static final int SHELLFISH_ALLERGY_SCORE = 4;
    private static final int STRAWBERRIES_ALLERGY_SCORE = 8;
    private static final int TOMATOS_ALLERGY_SCORE = 16;
    private static final int CHOCOLATE_ALLERGY_SCORE = 32;
    private static final int POLLEN_ALLERGY_SCORE = 64;
    private static final int CATS_ALLERGY_SCORE = 128;

    private int[] allergenScores = {CATS_ALLERGY_SCORE,
            EGG_ALLERGY_SCORE,
            PEANUTS_ALLERGY_SCORE,
            SHELLFISH_ALLERGY_SCORE,
            STRAWBERRIES_ALLERGY_SCORE,
            TOMATOS_ALLERGY_SCORE,
            CHOCOLATE_ALLERGY_SCORE,
            POLLEN_ALLERGY_SCORE};





    /*@Before
    public void setup() throws Exception
    {
       service = context.getBean(AllergyService.class);
    }*/

    @Test
    public void findAllergyList_1st()
    {
        service = new AllergyService();
        //service = context.getBean(AllergyService.class);

        setEnv(service);
        Integer[] expectedList = new Integer[]{CHOCOLATE_ALLERGY_SCORE,
                SHELLFISH_ALLERGY_SCORE,
                EGG_ALLERGY_SCORE};

        Assert.assertTrue(service.findAllergies(37).equals(Arrays.asList(expectedList)));
    }

    @Test // if the allergy score is 257, your program should only report the eggs
    public void findAllergyList_2nd()
    {
        service = new AllergyService();
        setEnv(service);
        Integer[] expectedList = new Integer[]{EGG_ALLERGY_SCORE};

        Assert.assertTrue(service.findAllergies(257).equals(Arrays.asList(expectedList)));
    }

    @Test
    public void noAllergiesMeansNotAllergicToAnything()
    {
        service = new AllergyService();
        int score = NO_ALLERGY_SCORE;
        setEnv(service);
        Assert.assertFalse(service.isAllergicTo(EGG,score));
        Assert.assertFalse(service.isAllergicTo(PEANUTS,score));
        Assert.assertFalse(service.isAllergicTo(SHELLFISH,score));
        Assert.assertFalse(service.isAllergicTo(STRAWBERRIES,score));
        Assert.assertFalse(service.isAllergicTo(TOMATOS,score));
        Assert.assertFalse(service.isAllergicTo(CHOCOLATE,score));
        Assert.assertFalse(service.isAllergicTo(POLLEN,score));
        Assert.assertFalse(service.isAllergicTo(CATS,score));
    }

    @Test
    public void allergicToEggs()
    {
        service = new AllergyService();
        setEnv(service);
        int score = EGG_ALLERGY_SCORE;
        Assert.assertTrue(service.isAllergicTo(EGG,score));
    }

    @Test
    public void allergicToEggsInAdditionToOtherStuff() {
        service = new AllergyService();
        setEnv(service);
        int score = 5;

        Assert.assertTrue(service.isAllergicTo(EGG,score));
        Assert.assertTrue(service.isAllergicTo(SHELLFISH,score));
    }

    @Test
    public void allergicToEggsShellFishButNotStrawberry() {
        service = new AllergyService();
        setEnv(service);
        int score = 5;

        Assert.assertTrue(service.isAllergicTo(EGG,score));
        Assert.assertTrue(service.isAllergicTo(SHELLFISH,score));
        Assert.assertFalse(service.isAllergicTo(STRAWBERRIES,score));

    }

    @Test
    public void isAllergicToEggsAndPeanuts() {
        service = new AllergyService();
        setEnv(service);
        int score = 3;

        Integer[] expectedList = new Integer[]{
                PEANUTS_ALLERGY_SCORE,
                EGG_ALLERGY_SCORE };

        Assert.assertTrue(service.findAllergies(score).equals(Arrays.asList(expectedList)));

    }

    private void setEnv(  AllergyService service)
    {
        service.setSortedAllergenScoresForTest(allergenScores);

        Map<Integer,String> map1  = new HashMap<>();
        map1.put(EGG_ALLERGY_SCORE,EGG);
        map1.put(PEANUTS_ALLERGY_SCORE,PEANUTS);
        map1.put(SHELLFISH_ALLERGY_SCORE,SHELLFISH);
        map1.put(STRAWBERRIES_ALLERGY_SCORE,STRAWBERRIES);
        map1.put(TOMATOS_ALLERGY_SCORE,TOMATOS);
        map1.put(CHOCOLATE_ALLERGY_SCORE,CHOCOLATE);
        map1.put(POLLEN_ALLERGY_SCORE,POLLEN);
        map1.put(CATS_ALLERGY_SCORE,CATS);

        service.setScoreMapToAllergen(map1);

        Map<String,Integer> map2  = new HashMap<>();
        map2.put(EGG,EGG_ALLERGY_SCORE);
        map2.put(PEANUTS,PEANUTS_ALLERGY_SCORE);
        map2.put(SHELLFISH,SHELLFISH_ALLERGY_SCORE);
        map2.put(STRAWBERRIES,STRAWBERRIES_ALLERGY_SCORE);
        map2.put(TOMATOS,TOMATOS_ALLERGY_SCORE);
        map2.put(CHOCOLATE,CHOCOLATE_ALLERGY_SCORE);
        map2.put(POLLEN,POLLEN_ALLERGY_SCORE);
        map2.put(CATS,CATS_ALLERGY_SCORE);

        service.setAllergenMapToScore(map2);
    }

}
