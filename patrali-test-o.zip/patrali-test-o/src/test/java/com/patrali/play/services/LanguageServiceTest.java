package com.patrali.play.services;

import org.testng.Assert;
import org.testng.annotations.Test;

/*
Some of the cases are checked based on https://en.wikipedia.org/wiki/Pig_Latin
 */
public class LanguageServiceTest
{
    @Test
    public void testRule1()
    {
        LanguageService service = new LanguageService();
        Assert.assertEquals(service.translate("APPLE"),"APPLEay");
        Assert.assertEquals(service.translate("I"),"Iay");
        Assert.assertEquals(service.translate("are"),"areay");
        Assert.assertEquals(service.translate("eat"),"eatay");
        Assert.assertEquals(service.translate("igloo"),"iglooay");
        Assert.assertEquals(service.translate("xray"),"xrayay");
        Assert.assertEquals(service.translate("yttria"),"yttriaay");
    }

    @Test
    public void testRule2()
    {
        LanguageService service = new LanguageService();
        Assert.assertEquals(service.translate("chair"),"airchay");
        Assert.assertEquals(service.translate("duck"),"uckday");
        Assert.assertEquals(service.translate("me"),"emay");
        Assert.assertEquals(service.translate("say"),"aysay");
        Assert.assertEquals(service.translate("will"),"illway");
        Assert.assertEquals(service.translate("go"),"ogay");
        Assert.assertEquals(service.translate("too"),"ootay");
        Assert.assertEquals(service.translate("string"),"ingstray");

    }

    @Test
    public void testRule3()
    {
        LanguageService service = new LanguageService();
        Assert.assertEquals(service.translate("square"),"aresquay");

    }

    @Test
    public void testRule4()
    {
        LanguageService service = new LanguageService();
        Assert.assertEquals(service.translate("rhythm"),"ythmrhay");
        Assert.assertEquals(service.translate("my"),"ymay");
        Assert.assertEquals(service.translate("THY"),"YTHay");
    }

    @Test
    public void testSentence()
    {
        LanguageService service = new LanguageService();
        Assert.assertEquals(service.translate("I will do it"),
                "Iay illway oday itay");
    }
}
