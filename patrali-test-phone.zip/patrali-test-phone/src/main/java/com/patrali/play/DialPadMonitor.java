package com.patrali.play;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import java.lang.invoke.MethodHandles;
import java.util.*;


@Component
public class DialPadMonitor
{

    private static final Logger LOG = LoggerFactory.getLogger( MethodHandles.lookup().lookupClass() );

    private Map<Integer,List<Integer>> elementAssociation = new HashMap();

    private Integer[][] dialpad = { {1   , 2   , 3},
                                    {4   , 5   , 6},
                                    {7   , 8   , 9},
                                    {null, 0   , null} };

    public void createDialAssociation()
    {
        int nosCols = dialpad[0].length;
        int nosRows = dialpad.length;
        int rowFrom, rowTo, colFrom, colTo;

        for(int row=0; row<nosRows; row++)
        {
            for(int col=0; col<nosCols; col++)
            {
                Integer currentElement = dialpad[row][col];
                if(currentElement == null)
                    continue;

                elementAssociation.put( currentElement, new ArrayList<Integer>());

                rowFrom =  (row-1)< 0 ? 0 : (row-1);
                rowTo = (row+1) <= (nosRows-1)? row+1: nosRows-1;
                colFrom = (col-1)<0 ? 0 : (col-1);
                colTo = (col+1) <= (nosCols-1) ? col+1 : nosCols-1;

                for(int currentRowIndex=rowFrom; currentRowIndex<=rowTo; currentRowIndex++)
                {
                    for(int currentColIndex = colFrom; currentColIndex <=colTo ; currentColIndex++)
                    {
                        if( dialpad[currentRowIndex][currentColIndex] != null)
                        {
                            elementAssociation.get(currentElement).add(dialpad[currentRowIndex][currentColIndex]);
                        }

                    }
                }

            }
        }

    }



    public void printAssociation()
    {
        LOG.info("------------------Association of each numbers in the dial pad------------------");
        elementAssociation.entrySet().stream().forEach( e -> LOG.info(e.getKey()+"="+Arrays.toString(e.getValue().toArray())) );
        LOG.info("-------------------------------------------------------------------------------");
    }

    public boolean isNoAssociated(int key, int target)
    {
        return elementAssociation.get(key).contains(target);
    }

    public boolean isNumberEasy(int currentNo)
    {
        if(String.valueOf(currentNo).length() == 1)
            return true;

        int key = currentNo % 10;
        currentNo = currentNo / 10;
        int target = currentNo % 10;

        if(!isNoAssociated(key,target))
            return false;

        LOG.debug("Next number: " + currentNo);
        return isNumberEasy(currentNo);

    }

    public void reportResult(int phoneNumber )
    {
        LOG.info(
                String.format(" %d is %s to dial",
                        phoneNumber,
                        isNumberEasy(phoneNumber)? " easy " : " not easy "));
    }

    public static void main( String args[] ) {
        ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
        DialPadMonitor service = context.getBean(DialPadMonitor.class);
        service.createDialAssociation();
        service.printAssociation();


        service.reportResult(159658521);
        service.reportResult(555555555);
        service.reportResult(505555555);
        service.reportResult(555555505);

    }

}
