package com.patrali.play;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import javax.annotation.PostConstruct;


@Test
@ContextConfiguration(locations = { "classpath:testContext.xml" })
public class DialPadMonitorTest extends AbstractTestNGSpringContextTests
{
    @Autowired
    DialPadMonitor service;


    @PostConstruct
    public void doBeforeTest()
    {
        service.createDialAssociation();
    }

    @Test()
    void testIfEasyToDial()
    {
        Assert.assertTrue(service.isNumberEasy(159658521));
        Assert.assertTrue(service.isNumberEasy(555555555));
        Assert.assertFalse(service.isNumberEasy(505555555));
        Assert.assertFalse(service.isNumberEasy(555555505));

        Assert.assertTrue(service.isNumberEasy(2547096));
        Assert.assertTrue(service.isNumberEasy(5547521));
        Assert.assertFalse(service.isNumberEasy(2806547));
        Assert.assertFalse(service.isNumberEasy(3558123));
    }

    @Test()
    void testIfAssociated()
    {
        service.createDialAssociation();

        Assert.assertTrue(service.isNoAssociated(3,3));
        Assert.assertTrue(service.isNoAssociated(3,6));
        Assert.assertFalse(service.isNoAssociated(3,9));

    }
}
