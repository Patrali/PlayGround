package com.patrali.play;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import java.lang.invoke.MethodHandles;
import java.util.Arrays;


@Component
public class Anagram
{

    private static final Logger LOG = LoggerFactory.getLogger( MethodHandles.lookup().lookupClass() );

    public boolean isAnagram(String str1, String str2)
    {
        if ( StringUtils.isEmpty(str1) || StringUtils.isEmpty(str2) )
        {
            return false;
        }

        char[] charSet1 = str1.toLowerCase().trim().replaceAll("\\s+","").toCharArray();
        char[] charSet2 = str2.toLowerCase().trim().replaceAll("\\s+","").toCharArray();
        Arrays.sort(charSet1);
        Arrays.sort(charSet2);

        return Arrays.toString(charSet1).equalsIgnoreCase(Arrays.toString(charSet2)) ;

    }

    public void reportAnagramResult( String str1, String str2 )
    {
        LOG.info(
                String.format(" %s and %s %s anagram to each other",
                        StringUtils.isEmpty(str1)? "empty/null": "'"+str1+"'",
                        StringUtils.isEmpty(str2)? "empty/null": "'"+str2+"'",
                        isAnagram(str1,str2)? " are " : " are not "));
    }

    public static void main( String args[] ) {
        ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
        Anagram service = context.getBean(Anagram.class);
        service.reportAnagramResult("", "Some Thing");
        service.reportAnagramResult("    ", "Some Thing");
        service.reportAnagramResult("", null);
        service.reportAnagramResult(null, null);
        service.reportAnagramResult("something", "Some Thing");
        service.reportAnagramResult("something", "Some Thing   ");
        service.reportAnagramResult("CoreLogic", "LogicCore");
        service.reportAnagramResult("Core", "Logic");
        service.reportAnagramResult("Core Logic" , "CoreLogic");
        service.reportAnagramResult("Core 1234" , "Core4321");
    }

}
