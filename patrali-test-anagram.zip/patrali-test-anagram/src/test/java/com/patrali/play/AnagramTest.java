package com.patrali.play;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.patrali.play.Anagram;


@Test
@ContextConfiguration(locations = { "classpath:testContext.xml" })
public class AnagramTest  extends AbstractTestNGSpringContextTests
{
    @Autowired
    Anagram anagram;

    @Test()
    void testAnagram()
    {
        Assert.assertFalse(anagram.isAnagram("","Some"));
        Assert.assertFalse(anagram.isAnagram("some","    "));
        Assert.assertFalse(anagram.isAnagram(null,null));
        Assert.assertTrue(anagram.isAnagram("some","Some"));
        Assert.assertTrue(anagram.isAnagram("something", "Some Thing"));
        Assert.assertTrue(anagram.isAnagram("something", "Some Thing    "));
        Assert.assertTrue(anagram.isAnagram("CoreLogic", "LogicCore"));
        Assert.assertFalse(anagram.isAnagram("Core", "Logic"));
        Assert.assertTrue(anagram.isAnagram("Core Logic" , "CoreLogic"));
        Assert.assertTrue(anagram.isAnagram("Core 1234" , "Core3421"));



    }
}
